package com.bloodrescue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class BloodRescueApplication {
    public static void main(String[] args) {
        SpringApplication.run(BloodRescueApplication.class, args);
    }
}
