package com.bloodrescue.service;

import com.bloodrescue.model.BloodGroups;
import com.bloodrescue.model.Role;
import com.bloodrescue.model.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Real-time updates using Server-Sent Events (SSE).
 * Every logged-in browser opens one long-lived connection to GET /api/events.
 * When a request is created / accepted / cancelled ... the service pushes a small "update" message to
 * the people concerned, and their dashboard reloads its data and shows a notification.
 */
@Service
public class LiveEventService {

    private record Client(String email, Role role, String bloodGroup, SseEmitter emitter) {
    }

    private final Set<Client> clients = ConcurrentHashMap.newKeySet();
    private final ObjectMapper mapper;

    public LiveEventService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    /** Called when a browser connects. */
    public SseEmitter subscribe(User user) {
        SseEmitter emitter = new SseEmitter(0L);   // 0 = never time out; dead connections are removed on failed sends
        Client client = new Client(user.getEmail(), user.getRole(), user.getBloodGroup(), emitter);
        clients.add(client);
        emitter.onCompletion(() -> clients.remove(client));
        emitter.onTimeout(() -> clients.remove(client));
        emitter.onError(e -> clients.remove(client));
        try {
            emitter.send(SseEmitter.event().name("ready").data("connected"));
        } catch (IOException | IllegalStateException e) {
            clients.remove(client);
        }
        return emitter;
    }

    /** Runs only after the database transaction that published the event has committed. */
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onEvent(LiveEvent e) {
        for (Client c : clients) {
            if (c.role() == Role.ADMIN) {
                send(c, e.requestId(), e.adminMsg());
            } else if (c.email().equalsIgnoreCase(e.requesterEmail())) {
                send(c, e.requestId(), e.requesterMsg());
            } else if (c.role() == Role.DONOR && c.email().equalsIgnoreCase(e.donorEmail())) {
                send(c, e.requestId(), e.donorMsg());
            } else if (c.role() == Role.DONOR && e.toPool() && e.bloodGroup() != null
                    && BloodGroups.canDonate(c.bloodGroup(), e.bloodGroup())) {
                send(c, e.requestId(), e.poolMsg());
            }
        }
    }

    /** Keeps connections alive through proxies and removes browsers that have gone away. */
    @Scheduled(fixedRate = 25000)
    public void heartbeat() {
        for (Client c : clients) {
            try {
                c.emitter().send(SseEmitter.event().comment("ping"));
            } catch (Exception ex) {
                clients.remove(c);
            }
        }
    }

    private void send(Client c, Long requestId, String message) {
        Map<String, Object> data = new HashMap<>();
        if (requestId != null) {
            data.put("requestId", requestId);
        }
        if (message != null) {
            data.put("message", message);
        }
        try {
            c.emitter().send(SseEmitter.event().name("update").data(mapper.writeValueAsString(data)));
        } catch (Exception ex) {
            clients.remove(c);
        }
    }
}
