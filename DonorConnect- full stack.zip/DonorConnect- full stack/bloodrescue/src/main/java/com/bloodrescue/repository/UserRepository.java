package com.bloodrescue.repository;

import com.bloodrescue.model.Role;
import com.bloodrescue.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

    Optional<User> findByEmailIgnoreCase(String email);

    boolean existsByEmailIgnoreCase(String email);

    List<User> findByRoleOrderByCreatedAtDesc(Role role);

    List<User> findAllByOrderByCreatedAtDesc();

    long countByRole(Role role);

    long countByRoleAndActiveTrueAndAvailableTrue(Role role);
}
