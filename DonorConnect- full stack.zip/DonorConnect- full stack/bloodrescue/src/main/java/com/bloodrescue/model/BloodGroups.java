package com.bloodrescue.model;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Blood group list and donor/recipient compatibility rules. */
public final class BloodGroups {

    public static final List<String> ALL = List.of("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-");

    /** recipient group -> donor groups that can give to that recipient */
    private static final Map<String, Set<String>> DONORS_FOR = Map.of(
            "A+", Set.of("A+", "A-", "O+", "O-"),
            "A-", Set.of("A-", "O-"),
            "B+", Set.of("B+", "B-", "O+", "O-"),
            "B-", Set.of("B-", "O-"),
            "AB+", Set.of("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"),
            "AB-", Set.of("A-", "B-", "AB-", "O-"),
            "O+", Set.of("O+", "O-"),
            "O-", Set.of("O-")
    );

    private BloodGroups() {
    }

    public static boolean isValid(String group) {
        return group != null && ALL.contains(group);
    }

    /** Can a donor of {@code donorGroup} donate to a patient of {@code recipientGroup}? */
    public static boolean canDonate(String donorGroup, String recipientGroup) {
        if (donorGroup == null || recipientGroup == null) {
            return false;
        }
        Set<String> donors = DONORS_FOR.get(recipientGroup);
        return donors != null && donors.contains(donorGroup);
    }

    /** All recipient groups a donor of {@code donorGroup} is able to help. */
    public static Set<String> recipientsFor(String donorGroup) {
        Set<String> result = new HashSet<>();
        for (String recipient : ALL) {
            if (canDonate(donorGroup, recipient)) {
                result.add(recipient);
            }
        }
        return result;
    }
}
