package com.bloodrescue.controller;

import com.bloodrescue.dto.Dtos.LoginRequest;
import com.bloodrescue.dto.Dtos.PasswordChange;
import com.bloodrescue.dto.Dtos.ProfileUpdate;
import com.bloodrescue.dto.Dtos.RegisterRequest;
import com.bloodrescue.dto.Dtos.UserDto;
import com.bloodrescue.exception.ApiException;
import com.bloodrescue.model.Role;
import com.bloodrescue.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Registration, login/logout (session cookie), current user and profile. */
@RestController
@RequestMapping("/api")
public class AuthController {

    private final AuthenticationManager authManager;
    private final SecurityContextRepository contextRepository;
    private final UserService userService;

    public AuthController(AuthenticationManager authManager, SecurityContextRepository contextRepository,
                          UserService userService) {
        this.authManager = authManager;
        this.contextRepository = contextRepository;
        this.userService = userService;
    }

    @PostMapping("/auth/register")
    public ResponseEntity<UserDto> register(@Valid @RequestBody RegisterRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(userService.register(req));
    }

    @PostMapping("/auth/login")
    public UserDto login(@Valid @RequestBody LoginRequest req, HttpServletRequest request, HttpServletResponse response) {
        Role wanted;
        try {
            wanted = Role.valueOf(req.role().trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Choose a valid account type");
        }

        Authentication auth;
        try {
            auth = authManager.authenticate(
                    UsernamePasswordAuthenticationToken.unauthenticated(req.email().trim(), req.password()));
        } catch (DisabledException e) {
            throw new ApiException(HttpStatus.FORBIDDEN, "Your account has been deactivated. Please contact the admin.");
        } catch (AuthenticationException e) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
        }

        // The login page asks "who are you?" (User / Donor / Admin): the account must really be of that type.
        Role actual = userService.getByEmail(auth.getName()).getRole();
        if (actual != wanted) {
            if (wanted == Role.ADMIN) {
                throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid email or password");
            }
            String type = actual == Role.DONOR ? "a Donor" : actual == Role.USER ? "a User" : "an Admin";
            String hint = actual == Role.ADMIN ? " Admins sign in through the admin portal." : " Please choose the correct account type.";
            throw new ApiException(HttpStatus.FORBIDDEN, "This account is registered as " + type + "." + hint);
        }

        SecurityContext context = SecurityContextHolder.createEmptyContext();
        context.setAuthentication(auth);
        SecurityContextHolder.setContext(context);
        contextRepository.saveContext(context, request, response);   // stores the login in the HTTP session
        return userService.me(auth.getName());
    }

    @PostMapping("/auth/logout")
    public Map<String, String> logout(HttpServletRequest request) {
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        SecurityContextHolder.clearContext();
        return Map.of("message", "Logged out");
    }

    @GetMapping("/auth/me")
    public UserDto me(Authentication auth) {
        return userService.me(auth.getName());
    }

    @PutMapping("/profile")
    public UserDto updateProfile(Authentication auth, @Valid @RequestBody ProfileUpdate req) {
        return userService.updateProfile(auth.getName(), req);
    }

    @PostMapping("/profile/password")
    public Map<String, String> changePassword(Authentication auth, @Valid @RequestBody PasswordChange req) {
        userService.changePassword(auth.getName(), req);
        return Map.of("message", "Password changed");
    }
}
