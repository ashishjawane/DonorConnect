package com.bloodrescue.controller;

import com.bloodrescue.dto.Dtos.AdminStats;
import com.bloodrescue.dto.Dtos.NoteBody;
import com.bloodrescue.dto.Dtos.RequestDto;
import com.bloodrescue.dto.Dtos.StatusBody;
import com.bloodrescue.dto.Dtos.StockDto;
import com.bloodrescue.dto.Dtos.StockUpdate;
import com.bloodrescue.dto.Dtos.UserDto;
import com.bloodrescue.service.AdminService;
import com.bloodrescue.service.RequestService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Endpoints for the blood management team (role ADMIN). */
@RestController
@RequestMapping("/api/admin")
public class AdminController {

    private final AdminService admin;
    private final RequestService requests;

    public AdminController(AdminService admin, RequestService requests) {
        this.admin = admin;
        this.requests = requests;
    }

    @GetMapping("/stats")
    public AdminStats stats() {
        return admin.stats();
    }

    // ------------------------------------------------------------ user requests

    @GetMapping("/requests")
    public List<RequestDto> listRequests(@RequestParam(required = false) String status) {
        return requests.adminList(status);
    }

    @PostMapping("/requests/{id}/reject")
    public RequestDto reject(@PathVariable Long id, @Valid @RequestBody NoteBody body) {
        return requests.reject(id, body.note());
    }

    @PostMapping("/requests/{id}/fulfill-from-stock")
    public RequestDto fulfillFromStock(@PathVariable Long id) {
        return requests.fulfillFromStock(id);
    }

    @PostMapping("/requests/{id}/fulfill")
    public RequestDto markFulfilled(@PathVariable Long id) {
        return requests.adminMarkFulfilled(id);
    }

    // ------------------------------------------------------------ donor history

    @GetMapping("/donations")
    public List<RequestDto> donorHistory() {
        return requests.donorHistoryForAdmin();
    }

    // ------------------------------------------------------------ manage users and donors

    /** role = USER or DONOR */
    @GetMapping("/users")
    public List<UserDto> users(@RequestParam String role) {
        return admin.usersByRole(role);
    }

    @PatchMapping("/users/{id}/status")
    public UserDto setStatus(@PathVariable Long id, @RequestBody StatusBody body) {
        return admin.setActive(id, body.active());
    }

    // ------------------------------------------------------------ blood stock

    @GetMapping("/stock")
    public List<StockDto> stock() {
        return admin.stockList();
    }

    @PutMapping("/stock/{bloodGroup}")
    public StockDto setStock(@PathVariable String bloodGroup, @Valid @RequestBody StockUpdate body) {
        return admin.setStock(bloodGroup, body.units());
    }
}
