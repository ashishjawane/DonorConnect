package com.bloodrescue.controller;

import com.bloodrescue.dto.Dtos.BloodRequestForm;
import com.bloodrescue.dto.Dtos.RequestDto;
import com.bloodrescue.service.RequestService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Endpoints for the blood requester (role USER). */
@RestController
@RequestMapping("/api/user")
public class UserController {

    private final RequestService service;

    public UserController(RequestService service) {
        this.service = service;
    }

    @GetMapping("/requests")
    public List<RequestDto> myRequests(Authentication auth) {
        return service.myRequests(auth.getName());
    }

    @PostMapping("/requests")
    public ResponseEntity<RequestDto> create(Authentication auth, @Valid @RequestBody BloodRequestForm form) {
        return ResponseEntity.status(HttpStatus.CREATED).body(service.create(auth.getName(), form));
    }

    @PostMapping("/requests/{id}/cancel")
    public RequestDto cancel(Authentication auth, @PathVariable Long id) {
        return service.cancel(auth.getName(), id);
    }
}
