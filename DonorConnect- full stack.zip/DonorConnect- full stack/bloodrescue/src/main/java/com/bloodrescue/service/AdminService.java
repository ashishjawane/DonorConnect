package com.bloodrescue.service;

import com.bloodrescue.dto.Dtos.AdminStats;
import com.bloodrescue.dto.Dtos.PublicStats;
import com.bloodrescue.dto.Dtos.StockDto;
import com.bloodrescue.dto.Dtos.UserDto;
import com.bloodrescue.dto.Mapper;
import com.bloodrescue.exception.ApiException;
import com.bloodrescue.model.BloodGroups;
import com.bloodrescue.model.BloodRequest;
import com.bloodrescue.model.BloodStock;
import com.bloodrescue.model.RequestStatus;
import com.bloodrescue.model.Role;
import com.bloodrescue.model.Urgency;
import com.bloodrescue.model.User;
import com.bloodrescue.repository.BloodRequestRepository;
import com.bloodrescue.repository.BloodStockRepository;
import com.bloodrescue.repository.UserRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AdminService {

    private final UserRepository users;
    private final BloodRequestRepository requests;
    private final BloodStockRepository stocks;
    private final ApplicationEventPublisher events;

    public AdminService(UserRepository users, BloodRequestRepository requests, BloodStockRepository stocks,
                        ApplicationEventPublisher events) {
        this.users = users;
        this.requests = requests;
        this.stocks = stocks;
        this.events = events;
    }

    @Transactional(readOnly = true)
    public AdminStats stats() {
        List<StockDto> stock = stockList();
        long totalUnits = stock.stream().mapToLong(StockDto::units).sum();
        return new AdminStats(
                users.countByRole(Role.USER),
                users.countByRole(Role.DONOR),
                users.countByRoleAndActiveTrueAndAvailableTrue(Role.DONOR),
                requests.count(),
                requests.countByStatus(RequestStatus.PENDING),
                requests.countByStatus(RequestStatus.ACCEPTED),
                requests.countByStatus(RequestStatus.FULFILLED),
                requests.countByStatus(RequestStatus.REJECTED),
                requests.countByStatus(RequestStatus.CANCELLED),
                requests.countByStatusAndUrgency(RequestStatus.PENDING, Urgency.CRITICAL),
                totalUnits, stock);
    }

    /** Numbers for the public home page. */
    @Transactional(readOnly = true)
    public PublicStats publicStats() {
        return new PublicStats(
                users.countByRole(Role.DONOR),
                requests.countByStatus(RequestStatus.FULFILLED),
                requests.count());
    }

    // ---------------------------------------------------------------- users and donors

    /** role = USER (requesters) or DONOR. Admin accounts are never listed or changed here. */
    @Transactional(readOnly = true)
    public List<UserDto> usersByRole(String role) {
        Role r;
        try {
            r = Role.valueOf(role.trim().toUpperCase());
        } catch (IllegalArgumentException | NullPointerException e) {
            throw ApiException.badRequest("Role must be USER or DONOR");
        }
        if (r == Role.ADMIN) {
            throw ApiException.badRequest("Role must be USER or DONOR");
        }
        return users.findByRoleOrderByCreatedAtDesc(r).stream().map(Mapper::user).toList();
    }

    @Transactional
    public UserDto setActive(Long id, boolean active) {
        User u = users.findById(id).orElseThrow(() -> ApiException.notFound("User not found"));
        if (u.getRole() == Role.ADMIN) {
            throw ApiException.forbidden("Admin accounts cannot be changed here");
        }
        u.setActive(active);
        if (!active) {
            // a deactivated donor must not hold on to an accepted request: send it back to the open list
            for (BloodRequest r : requests.findByAcceptedByAndStatus(u, RequestStatus.ACCEPTED)) {
                r.setAcceptedBy(null);
                r.setStatus(RequestStatus.PENDING);
                events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                        r.getRequester().getEmail(),
                        "The donor is no longer available. Your request is open to other donors again.",
                        null, null,
                        "Request #" + r.getId() + " is open again because donor " + u.getName() + " was deactivated.",
                        true, "Request open again: " + r.getBloodGroup() + ", " + r.getUnits() + " unit(s), " + r.getHospital()));
            }
        }
        return Mapper.user(u);
    }

    // ---------------------------------------------------------------- stock

    @Transactional(readOnly = true)
    public List<StockDto> stockList() {
        return BloodGroups.ALL.stream()
                .map(g -> new StockDto(g, stocks.findByBloodGroup(g).map(BloodStock::getUnits).orElse(0)))
                .toList();
    }

    @Transactional
    public StockDto setStock(String bloodGroup, int units) {
        if (!BloodGroups.isValid(bloodGroup)) {
            throw ApiException.badRequest("Invalid blood group");
        }
        BloodStock s = stocks.findByBloodGroup(bloodGroup).orElseGet(() -> new BloodStock(bloodGroup, 0));
        s.setUnits(units);
        stocks.save(s);
        return new StockDto(s.getBloodGroup(), s.getUnits());
    }
}
