package com.bloodrescue.service;

/**
 * Something changed and connected browsers should refresh.
 * Published inside a transaction and delivered only after it commits (see {@link LiveEventService}).
 *
 * @param requestId      related request, may be null
 * @param bloodGroup     blood group of the request (used to pick matching donors)
 * @param requesterEmail requester who should be told, may be null
 * @param requesterMsg   toast text for the requester, may be null (refresh without a toast)
 * @param donorEmail     one specific donor who should be told, may be null
 * @param donorMsg       toast text for that donor
 * @param adminMsg       toast text for every admin (admins always receive a refresh)
 * @param toPool         also refresh every available donor whose blood group can give to {@code bloodGroup}
 * @param poolMsg        toast text for those donors, may be null
 */
public record LiveEvent(Long requestId, String bloodGroup,
                        String requesterEmail, String requesterMsg,
                        String donorEmail, String donorMsg,
                        String adminMsg,
                        boolean toPool, String poolMsg) {
}
