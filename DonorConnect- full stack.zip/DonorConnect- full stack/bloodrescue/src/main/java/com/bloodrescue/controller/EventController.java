package com.bloodrescue.controller;

import com.bloodrescue.service.LiveEventService;
import com.bloodrescue.service.UserService;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/** Real-time stream for the logged-in user (all roles). */
@RestController
@RequestMapping("/api")
public class EventController {

    private final LiveEventService live;
    private final UserService users;

    public EventController(LiveEventService live, UserService users) {
        this.live = live;
        this.users = users;
    }

    @GetMapping(value = "/events", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter stream(Authentication auth) {
        return live.subscribe(users.getByEmail(auth.getName()));
    }
}
