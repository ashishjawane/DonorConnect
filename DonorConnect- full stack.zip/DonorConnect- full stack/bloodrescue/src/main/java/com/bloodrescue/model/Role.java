package com.bloodrescue.model;

public enum Role {
    USER,   // person who needs blood (requester / patient family)
    DONOR,  // person who donates blood
    ADMIN   // blood management team
}
