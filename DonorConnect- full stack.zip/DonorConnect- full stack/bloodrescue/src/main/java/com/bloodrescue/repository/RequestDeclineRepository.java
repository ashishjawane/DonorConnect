package com.bloodrescue.repository;

import com.bloodrescue.model.RequestDecline;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface RequestDeclineRepository extends JpaRepository<RequestDecline, Long> {

    boolean existsByRequestIdAndDonorId(Long requestId, Long donorId);

    @Query("select d.request.id from RequestDecline d where d.donor.id = :donorId")
    List<Long> findRequestIdsByDonorId(@Param("donorId") Long donorId);
}
