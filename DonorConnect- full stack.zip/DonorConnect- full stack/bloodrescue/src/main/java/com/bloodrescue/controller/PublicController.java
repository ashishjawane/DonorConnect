package com.bloodrescue.controller;

import com.bloodrescue.dto.Dtos.PublicStats;
import com.bloodrescue.service.AdminService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** Numbers shown on the public home page (no login needed). */
@RestController
@RequestMapping("/api/public")
public class PublicController {

    private final AdminService admin;

    public PublicController(AdminService admin) {
        this.admin = admin;
    }

    @GetMapping("/stats")
    public PublicStats stats() {
        return admin.publicStats();
    }
}
