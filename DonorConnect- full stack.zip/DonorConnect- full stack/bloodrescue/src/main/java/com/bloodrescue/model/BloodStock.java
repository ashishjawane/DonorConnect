package com.bloodrescue.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;

import java.time.LocalDateTime;

/** Units of blood available in the blood bank for each blood group (managed by admin). */
@Entity
@Table(name = "blood_stock")
public class BloodStock {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 4)
    private String bloodGroup;

    @Column(nullable = false)
    private int units;

    @Column(nullable = false)
    private LocalDateTime updatedAt;

    public BloodStock() {
    }

    public BloodStock(String bloodGroup, int units) {
        this.bloodGroup = bloodGroup;
        this.units = units;
    }

    @PrePersist
    @PreUpdate
    void touch() {
        updatedAt = LocalDateTime.now();
    }

    public Long getId() { return id; }
    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }
    public int getUnits() { return units; }
    public void setUnits(int units) { this.units = units; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
}
