package com.bloodrescue.model;

/** Order matters: higher ordinal = more urgent. */
public enum Urgency {
    NORMAL, URGENT, CRITICAL
}
