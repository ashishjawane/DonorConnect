package com.bloodrescue.config;

import com.bloodrescue.model.BloodGroups;
import com.bloodrescue.model.BloodRequest;
import com.bloodrescue.model.BloodStock;
import com.bloodrescue.model.RequestStatus;
import com.bloodrescue.model.Role;
import com.bloodrescue.model.Urgency;
import com.bloodrescue.model.User;
import com.bloodrescue.repository.BloodRequestRepository;
import com.bloodrescue.repository.BloodStockRepository;
import com.bloodrescue.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

/** Creates the admin account, empty blood stock and (optionally) demo data on first start. */
@Component
public class DataSeeder implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);

    private final UserRepository users;
    private final BloodRequestRepository requests;
    private final BloodStockRepository stocks;
    private final PasswordEncoder encoder;

    @Value("${bloodrescue.seed-demo-data:true}")
    private boolean seedDemoData;

    public DataSeeder(UserRepository users, BloodRequestRepository requests,
                      BloodStockRepository stocks, PasswordEncoder encoder) {
        this.users = users;
        this.requests = requests;
        this.stocks = stocks;
        this.encoder = encoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        for (String group : BloodGroups.ALL) {
            if (stocks.findByBloodGroup(group).isEmpty()) {
                stocks.save(new BloodStock(group, seedDemoData ? 8 : 0));
            }
        }

        if (users.count() > 0) {
            return;
        }

        User admin = newUser("Blood Bank Admin", "admin@bloodrescue.com", "Admin@123", "9000000001", "Pune", null, Role.ADMIN);
        users.save(admin);
        log.info("Created admin account: admin@bloodrescue.com / Admin@123  (change this password after first login)");

        if (!seedDemoData) {
            return;
        }

        User donor1 = users.save(newUser("Rahul Patil", "donor@bloodrescue.com", "Donor@123", "9000000002", "Pune", "O+", Role.DONOR));
        users.save(newUser("Sneha Kulkarni", "donor2@bloodrescue.com", "Donor@123", "9000000003", "Pune", "A+", Role.DONOR));
        User requester = users.save(newUser("Amit Shah", "user@bloodrescue.com", "User@123", "9000000004", "Pune", null, Role.USER));

        BloodRequest pending = request(requester, "Meera Shah", "A+", 1, "Ruby Hall Clinic", "Pune", Urgency.URGENT, 2);
        BloodRequest critical = request(requester, "Ramesh Shah", "O+", 2, "Sassoon Hospital", "Pune", Urgency.CRITICAL, 1);
        requests.save(pending);
        requests.save(critical);
        log.info("Seeded demo donors, requester and sample requests (donor1 = {})", donor1.getEmail());
    }

    private User newUser(String name, String email, String rawPassword, String phone, String city, String group, Role role) {
        User u = new User();
        u.setName(name);
        u.setEmail(email);
        u.setPassword(encoder.encode(rawPassword));
        u.setPhone(phone);
        u.setCity(city);
        u.setBloodGroup(group);
        u.setRole(role);
        return u;
    }

    private BloodRequest request(User requester, String patient, String group, int units, String hospital,
                                 String city, Urgency urgency, int daysAhead) {
        BloodRequest r = new BloodRequest();
        r.setRequester(requester);
        r.setPatientName(patient);
        r.setBloodGroup(group);
        r.setUnits(units);
        r.setHospital(hospital);
        r.setCity(city);
        r.setUrgency(urgency);
        r.setRequiredDate(LocalDate.now().plusDays(daysAhead));
        r.setNote("Sample request created by the demo seeder.");
        r.setStatus(RequestStatus.PENDING);
        return r;
    }
}
