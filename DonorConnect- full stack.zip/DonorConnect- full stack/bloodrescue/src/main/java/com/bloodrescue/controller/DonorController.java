package com.bloodrescue.controller;

import com.bloodrescue.dto.Dtos.AvailabilityBody;
import com.bloodrescue.dto.Dtos.DonorStats;
import com.bloodrescue.dto.Dtos.RequestDto;
import com.bloodrescue.service.RequestService;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Endpoints for the blood donor (role DONOR). */
@RestController
@RequestMapping("/api/donor")
public class DonorController {

    private final RequestService service;

    public DonorController(RequestService service) {
        this.service = service;
    }

    @GetMapping("/stats")
    public DonorStats stats(Authentication auth) {
        return service.donorStats(auth.getName());
    }

    @PutMapping("/availability")
    public Map<String, Boolean> availability(Authentication auth, @RequestBody AvailabilityBody body) {
        service.setAvailability(auth.getName(), body.available());
        return Map.of("available", body.available());
    }

    @GetMapping("/requests/open")
    public List<RequestDto> open(Authentication auth) {
        return service.openForDonor(auth.getName());
    }

    @GetMapping("/requests/mine")
    public List<RequestDto> mine(Authentication auth) {
        return service.donorHistory(auth.getName());
    }

    @PostMapping("/requests/{id}/accept")
    public RequestDto accept(Authentication auth, @PathVariable Long id) {
        return service.accept(auth.getName(), id);
    }

    @PostMapping("/requests/{id}/reject")
    public Map<String, String> reject(Authentication auth, @PathVariable Long id) {
        service.decline(auth.getName(), id);
        return Map.of("message", "Request rejected");
    }

    @PostMapping("/requests/{id}/release")
    public RequestDto release(Authentication auth, @PathVariable Long id) {
        return service.release(auth.getName(), id);
    }

    @PostMapping("/requests/{id}/complete")
    public RequestDto complete(Authentication auth, @PathVariable Long id) {
        return service.complete(auth.getName(), id);
    }
}
