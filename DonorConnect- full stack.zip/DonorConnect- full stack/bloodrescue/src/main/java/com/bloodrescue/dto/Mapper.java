package com.bloodrescue.dto;

import com.bloodrescue.dto.Dtos.RequestDto;
import com.bloodrescue.dto.Dtos.UserDto;
import com.bloodrescue.model.BloodRequest;
import com.bloodrescue.model.User;

/** Converts entities to response objects. Passwords are never exposed. */
public final class Mapper {

    private Mapper() {
    }

    public static UserDto user(User u) {
        return new UserDto(u.getId(), u.getName(), u.getEmail(), u.getPhone(), u.getCity(), u.getBloodGroup(),
                u.getRole().name(), u.isActive(), u.isAvailable(), u.getLastDonationDate(),
                u.getTotalDonations(), u.getCreatedAt());
    }

    /**
     * @param showRequesterContact whether the requester's phone/email may be shown to the viewer
     * @param showDonorContact     whether the accepting donor's phone may be shown to the viewer
     */
    public static RequestDto request(BloodRequest r, boolean showRequesterContact, boolean showDonorContact) {
        User requester = r.getRequester();
        User donor = r.getAcceptedBy();
        return new RequestDto(
                r.getId(), r.getPatientName(), r.getBloodGroup(), r.getUnits(), r.getHospital(), r.getCity(),
                r.getUrgency().name(), r.getRequiredDate(), r.getNote(), r.getStatus().name(), r.getAdminNote(),
                r.isFulfilledFromStock(), r.getCreatedAt(), r.getUpdatedAt(),
                requester.getName(),
                showRequesterContact ? requester.getPhone() : null,
                showRequesterContact ? requester.getEmail() : null,
                donor == null ? null : donor.getName(),
                donor != null && showDonorContact ? donor.getPhone() : null,
                donor == null ? null : donor.getBloodGroup());
    }
}
