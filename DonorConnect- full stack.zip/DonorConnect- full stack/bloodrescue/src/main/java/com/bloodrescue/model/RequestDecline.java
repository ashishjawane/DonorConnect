package com.bloodrescue.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;

import java.time.LocalDateTime;

/** A donor pressed "Reject" on a request: it is hidden from that donor's list (other donors still see it). */
@Entity
@Table(name = "request_declines",
        uniqueConstraints = @UniqueConstraint(columnNames = {"request_id", "donor_id"}))
public class RequestDecline {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "request_id", nullable = false)
    private BloodRequest request;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "donor_id", nullable = false)
    private User donor;

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    protected RequestDecline() {
    }

    public RequestDecline(BloodRequest request, User donor) {
        this.request = request;
        this.donor = donor;
    }

    public Long getId() { return id; }
    public BloodRequest getRequest() { return request; }
    public User getDonor() { return donor; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
