package com.bloodrescue.service;

import com.bloodrescue.dto.Dtos.BloodRequestForm;
import com.bloodrescue.dto.Dtos.DonorStats;
import com.bloodrescue.dto.Dtos.RequestDto;
import com.bloodrescue.dto.Mapper;
import com.bloodrescue.exception.ApiException;
import com.bloodrescue.model.BloodGroups;
import com.bloodrescue.model.BloodRequest;
import com.bloodrescue.model.BloodStock;
import com.bloodrescue.model.RequestDecline;
import com.bloodrescue.model.RequestStatus;
import com.bloodrescue.model.User;
import com.bloodrescue.repository.BloodRequestRepository;
import com.bloodrescue.repository.BloodStockRepository;
import com.bloodrescue.repository.RequestDeclineRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Business rules for the blood request life cycle (requester, donor and admin actions).
 * Every change publishes a {@link LiveEvent} so that open dashboards update in real time.
 */
@Service
public class RequestService {

    /** A donor must wait this many days between donations. */
    public static final int ELIGIBILITY_DAYS = 90;

    private final BloodRequestRepository requests;
    private final BloodStockRepository stocks;
    private final RequestDeclineRepository declines;
    private final UserService userService;
    private final ApplicationEventPublisher events;

    public RequestService(BloodRequestRepository requests, BloodStockRepository stocks,
                          RequestDeclineRepository declines, UserService userService,
                          ApplicationEventPublisher events) {
        this.requests = requests;
        this.stocks = stocks;
        this.declines = declines;
        this.userService = userService;
        this.events = events;
    }

    private BloodRequest find(Long id) {
        return requests.findById(id).orElseThrow(() -> ApiException.notFound("Request not found"));
    }

    private static String describe(BloodRequest r) {
        return r.getBloodGroup() + ", " + r.getUnits() + " unit(s), " + r.getHospital();
    }

    // =====================================================================================
    // REQUESTER (role USER)
    // =====================================================================================

    @Transactional
    public RequestDto create(String email, BloodRequestForm f) {
        User user = userService.getByEmail(email);
        if (!BloodGroups.isValid(f.bloodGroup())) {
            throw ApiException.badRequest("Invalid blood group");
        }
        if (f.requiredDate().isBefore(LocalDate.now())) {
            throw ApiException.badRequest("Required date cannot be in the past");
        }
        BloodRequest r = new BloodRequest();
        r.setRequester(user);
        r.setPatientName(f.patientName().trim());
        r.setBloodGroup(f.bloodGroup());
        r.setUnits(f.units());
        r.setHospital(f.hospital().trim());
        r.setCity(f.city().trim());
        r.setUrgency(f.urgency());
        r.setRequiredDate(f.requiredDate());
        r.setNote(f.note() == null || f.note().isBlank() ? null : f.note().trim());
        r.setStatus(RequestStatus.PENDING);
        BloodRequest saved = requests.save(r);

        events.publishEvent(new LiveEvent(saved.getId(), saved.getBloodGroup(),
                user.getEmail(), null,
                null, null,
                "New " + saved.getUrgency() + " request #" + saved.getId() + " from " + user.getName() + ": " + describe(saved),
                true, saved.getUrgency() + " request for " + describe(saved)));
        return Mapper.request(saved, true, true);
    }

    @Transactional(readOnly = true)
    public List<RequestDto> myRequests(String email) {
        User user = userService.getByEmail(email);
        return requests.findByRequesterOrderByCreatedAtDesc(user).stream()
                .map(r -> Mapper.request(r, true, true)).toList();
    }

    @Transactional
    public RequestDto cancel(String email, Long id) {
        User user = userService.getByEmail(email);
        BloodRequest r = find(id);
        if (!r.getRequester().getId().equals(user.getId())) {
            throw ApiException.forbidden("This is not your request");
        }
        if (r.getStatus() != RequestStatus.PENDING && r.getStatus() != RequestStatus.ACCEPTED) {
            throw ApiException.conflict("Only requests that are waiting for a donor or accepted can be cancelled");
        }
        User donor = r.getAcceptedBy();
        r.setStatus(RequestStatus.CANCELLED);

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                user.getEmail(), null,
                donor == null ? null : donor.getEmail(),
                "The requester cancelled the request for " + r.getPatientName() + ".",
                "Request #" + r.getId() + " was cancelled by " + user.getName(),
                true, null));
        return Mapper.request(r, true, true);
    }

    // =====================================================================================
    // DONOR (role DONOR)
    // =====================================================================================

    public static boolean isEligible(User donor) {
        LocalDate next = nextEligibleDate(donor);
        return next == null || !next.isAfter(LocalDate.now());
    }

    public static LocalDate nextEligibleDate(User donor) {
        return donor.getLastDonationDate() == null ? null : donor.getLastDonationDate().plusDays(ELIGIBILITY_DAYS);
    }

    /** Pending requests this donor can give to and has not rejected, most urgent first. */
    private List<BloodRequest> openEntities(User donor) {
        if (donor.getBloodGroup() == null) {
            return List.of();
        }
        Set<String> groups = BloodGroups.recipientsFor(donor.getBloodGroup());
        Set<Long> rejected = new HashSet<>(declines.findRequestIdsByDonorId(donor.getId()));
        return requests.findByStatusAndBloodGroupIn(RequestStatus.PENDING, groups).stream()
                .filter(r -> !rejected.contains(r.getId()))
                .sorted(Comparator.comparingInt((BloodRequest r) -> r.getUrgency().ordinal()).reversed()
                        .thenComparing(BloodRequest::getRequiredDate))
                .toList();
    }

    @Transactional(readOnly = true)
    public List<RequestDto> openForDonor(String email) {
        User donor = userService.getByEmail(email);
        return openEntities(donor).stream()
                .map(r -> Mapper.request(r, false, false))   // contact details stay hidden until accepted
                .toList();
    }

    @Transactional(readOnly = true)
    public List<RequestDto> donorHistory(String email) {
        User donor = userService.getByEmail(email);
        return requests.findByAcceptedByOrderByUpdatedAtDesc(donor).stream()
                .map(r -> Mapper.request(r, true, true)).toList();
    }

    @Transactional(readOnly = true)
    public DonorStats donorStats(String email) {
        User donor = userService.getByEmail(email);
        return new DonorStats(donor.getBloodGroup(), donor.isAvailable(), donor.getTotalDonations(),
                donor.getLastDonationDate(), isEligible(donor), nextEligibleDate(donor),
                openEntities(donor).size(),
                requests.existsByAcceptedByAndStatus(donor, RequestStatus.ACCEPTED));
    }

    @Transactional
    public void setAvailability(String email, boolean available) {
        userService.getByEmail(email).setAvailable(available);
    }

    @Transactional
    public RequestDto accept(String email, Long id) {
        User donor = userService.getByEmail(email);
        if (!donor.isAvailable()) {
            throw ApiException.conflict("Turn on your availability before accepting a request");
        }
        if (!isEligible(donor)) {
            throw ApiException.conflict("You can donate again on " + nextEligibleDate(donor));
        }
        if (requests.existsByAcceptedByAndStatus(donor, RequestStatus.ACCEPTED)) {
            throw ApiException.conflict("Complete or withdraw your current accepted request first");
        }
        BloodRequest r = find(id);
        if (r.getStatus() != RequestStatus.PENDING) {
            throw ApiException.conflict("This request was just taken by another donor or is no longer open");
        }
        if (!BloodGroups.canDonate(donor.getBloodGroup(), r.getBloodGroup())) {
            throw ApiException.badRequest("Your blood group cannot donate to this patient");
        }
        r.setAcceptedBy(donor);
        r.setStatus(RequestStatus.ACCEPTED);

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                r.getRequester().getEmail(),
                donor.getName() + " accepted your request for " + r.getPatientName() + ". Contact details are in Request history.",
                null, null,
                donor.getName() + " (" + donor.getBloodGroup() + ") accepted request #" + r.getId() + " for " + r.getPatientName(),
                true, null));   // other donors: the request disappears from their list
        return Mapper.request(r, true, true);
    }

    /** Donor presses "Reject": the request is hidden from this donor only. */
    @Transactional
    public void decline(String email, Long id) {
        User donor = userService.getByEmail(email);
        BloodRequest r = find(id);
        if (r.getStatus() != RequestStatus.PENDING) {
            throw ApiException.conflict("This request is no longer open");
        }
        if (!declines.existsByRequestIdAndDonorId(id, donor.getId())) {
            declines.save(new RequestDecline(r, donor));
        }
    }

    /** Donor changes their mind after accepting: the request goes back to the open list. */
    @Transactional
    public RequestDto release(String email, Long id) {
        BloodRequest r = acceptedByDonor(email, id);
        User donor = r.getAcceptedBy();
        r.setAcceptedBy(null);
        r.setStatus(RequestStatus.PENDING);

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                r.getRequester().getEmail(),
                donor.getName() + " withdrew. Your request is open to other donors again.",
                null, null,
                donor.getName() + " withdrew from request #" + r.getId() + ". It is open again.",
                true, "Request open again: " + describe(r)));
        return Mapper.request(r, false, false);
    }

    /** Donor confirms that the donation is done. */
    @Transactional
    public RequestDto complete(String email, Long id) {
        BloodRequest r = acceptedByDonor(email, id);
        User donor = r.getAcceptedBy();
        markDonated(r);

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                r.getRequester().getEmail(),
                "Donation completed for " + r.getPatientName() + ". Thank you to " + donor.getName() + "!",
                null, null,
                donor.getName() + " completed the donation for request #" + r.getId(),
                false, null));
        return Mapper.request(r, true, true);
    }

    private BloodRequest acceptedByDonor(String email, Long id) {
        User donor = userService.getByEmail(email);
        BloodRequest r = find(id);
        if (r.getStatus() != RequestStatus.ACCEPTED || r.getAcceptedBy() == null
                || !r.getAcceptedBy().getId().equals(donor.getId())) {
            throw ApiException.conflict("This request is not currently accepted by you");
        }
        return r;
    }

    private void markDonated(BloodRequest r) {
        User donor = r.getAcceptedBy();
        r.setStatus(RequestStatus.FULFILLED);
        donor.setLastDonationDate(LocalDate.now());
        donor.setTotalDonations(donor.getTotalDonations() + 1);
    }

    // =====================================================================================
    // ADMIN (blood management team)
    // =====================================================================================

    @Transactional(readOnly = true)
    public List<RequestDto> adminList(String status) {
        List<BloodRequest> list;
        if (status == null || status.isBlank() || status.equalsIgnoreCase("ALL")) {
            list = requests.findAllByOrderByCreatedAtDesc();
        } else {
            try {
                list = requests.findByStatusOrderByCreatedAtDesc(RequestStatus.valueOf(status.toUpperCase()));
            } catch (IllegalArgumentException e) {
                throw ApiException.badRequest("Unknown status: " + status);
            }
        }
        return list.stream().map(r -> Mapper.request(r, true, true)).toList();
    }

    /** Every request that a donor has accepted - the donor history. */
    @Transactional(readOnly = true)
    public List<RequestDto> donorHistoryForAdmin() {
        return requests.findByAcceptedByIsNotNullOrderByUpdatedAtDesc().stream()
                .map(r -> Mapper.request(r, true, true)).toList();
    }

    @Transactional
    public RequestDto reject(Long id, String note) {
        BloodRequest r = find(id);
        if (r.getStatus() != RequestStatus.PENDING && r.getStatus() != RequestStatus.ACCEPTED) {
            throw ApiException.conflict("Only pending or accepted requests can be rejected");
        }
        if (blankToNull(note) == null) {
            throw ApiException.badRequest("Please give a reason for rejecting the request");
        }
        User donor = r.getAcceptedBy();
        r.setStatus(RequestStatus.REJECTED);
        r.setAdminNote(note.trim());

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                r.getRequester().getEmail(),
                "Your request for " + r.getPatientName() + " was rejected: " + note.trim(),
                donor == null ? null : donor.getEmail(),
                "Request #" + r.getId() + " was closed by the admin team: " + note.trim(),
                null,
                true, null));
        return Mapper.request(r, true, true);
    }

    /** Give blood from the blood-bank stock instead of waiting for a donor. */
    @Transactional
    public RequestDto fulfillFromStock(Long id) {
        BloodRequest r = find(id);
        if (r.getStatus() != RequestStatus.PENDING) {
            throw ApiException.conflict("Only requests that are waiting for a donor can be fulfilled from stock");
        }
        BloodStock stock = stocks.findByBloodGroup(r.getBloodGroup())
                .orElseThrow(() -> ApiException.conflict("No stock recorded for " + r.getBloodGroup()));
        if (stock.getUnits() < r.getUnits()) {
            throw ApiException.conflict("Only " + stock.getUnits() + " unit(s) of " + r.getBloodGroup() + " in stock");
        }
        stock.setUnits(stock.getUnits() - r.getUnits());
        r.setStatus(RequestStatus.FULFILLED);
        r.setFulfilledFromStock(true);

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                r.getRequester().getEmail(),
                "Good news: your request for " + r.getPatientName() + " was fulfilled from the blood bank stock.",
                null, null,
                null,
                true, null));
        return Mapper.request(r, true, true);
    }

    /** Admin confirms a donation made by the accepted donor. */
    @Transactional
    public RequestDto adminMarkFulfilled(Long id) {
        BloodRequest r = find(id);
        if (r.getStatus() != RequestStatus.ACCEPTED || r.getAcceptedBy() == null) {
            throw ApiException.conflict("Only accepted requests can be marked as fulfilled");
        }
        User donor = r.getAcceptedBy();
        markDonated(r);

        events.publishEvent(new LiveEvent(r.getId(), r.getBloodGroup(),
                r.getRequester().getEmail(),
                "Your request for " + r.getPatientName() + " was marked as fulfilled.",
                donor.getEmail(),
                "Your donation for " + r.getPatientName() + " was confirmed. Thank you!",
                null,
                false, null));
        return Mapper.request(r, true, true);
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
