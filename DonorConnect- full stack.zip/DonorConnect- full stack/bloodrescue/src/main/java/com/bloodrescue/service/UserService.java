package com.bloodrescue.service;

import com.bloodrescue.dto.Dtos.PasswordChange;
import com.bloodrescue.dto.Dtos.ProfileUpdate;
import com.bloodrescue.dto.Dtos.RegisterRequest;
import com.bloodrescue.dto.Dtos.UserDto;
import com.bloodrescue.dto.Mapper;
import com.bloodrescue.exception.ApiException;
import com.bloodrescue.model.BloodGroups;
import com.bloodrescue.model.Role;
import com.bloodrescue.model.User;
import com.bloodrescue.repository.UserRepository;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class UserService {

    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final ApplicationEventPublisher events;

    public UserService(UserRepository users, PasswordEncoder encoder, ApplicationEventPublisher events) {
        this.users = users;
        this.encoder = encoder;
        this.events = events;
    }

    public User getByEmail(String email) {
        User u = users.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new ApiException(HttpStatus.UNAUTHORIZED, "Please log in again."));
        if (!u.isActive()) {
            // account was deactivated by the admin while the session was still open
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Your account has been deactivated.");
        }
        return u;
    }

    @Transactional(readOnly = true)
    public UserDto me(String email) {
        return Mapper.user(getByEmail(email));
    }

    @Transactional
    public UserDto register(RegisterRequest req) {
        Role role;
        try {
            role = Role.valueOf(req.role().trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            throw ApiException.badRequest("Role must be USER or DONOR");
        }
        if (role == Role.ADMIN) {
            throw ApiException.badRequest("Admin accounts cannot be self-registered");
        }

        String group = blankToNull(req.bloodGroup());
        if (role == Role.DONOR && group == null) {
            throw ApiException.badRequest("Blood group is required for donors");
        }
        if (group != null && !BloodGroups.isValid(group)) {
            throw ApiException.badRequest("Invalid blood group");
        }

        String email = req.email().trim().toLowerCase();
        if (users.existsByEmailIgnoreCase(email)) {
            throw ApiException.conflict("This email is already registered");
        }

        User u = new User();
        u.setName(req.name().trim());
        u.setEmail(email);
        u.setPassword(encoder.encode(req.password()));
        u.setPhone(req.phone().trim());
        u.setCity(req.city().trim());
        u.setBloodGroup(group);
        u.setRole(role);
        User saved = users.save(u);

        events.publishEvent(new LiveEvent(null, null, null, null, null, null,
                "New " + (role == Role.DONOR ? "donor" : "user") + " registered: " + saved.getName()
                        + (group == null ? "" : " (" + group + ")"),
                false, null));
        return Mapper.user(saved);
    }

    @Transactional
    public UserDto updateProfile(String email, ProfileUpdate req) {
        User u = getByEmail(email);
        String group = blankToNull(req.bloodGroup());
        if (u.getRole() == Role.DONOR && group == null) {
            throw ApiException.badRequest("Blood group is required for donors");
        }
        if (group != null && !BloodGroups.isValid(group)) {
            throw ApiException.badRequest("Invalid blood group");
        }
        u.setName(req.name().trim());
        u.setPhone(req.phone().trim());
        u.setCity(req.city().trim());
        if (u.getRole() != Role.ADMIN) {
            u.setBloodGroup(group);
        }
        return Mapper.user(u);
    }

    @Transactional
    public void changePassword(String email, PasswordChange req) {
        User u = getByEmail(email);
        if (!encoder.matches(req.currentPassword(), u.getPassword())) {
            throw ApiException.badRequest("Current password is incorrect");
        }
        u.setPassword(encoder.encode(req.newPassword()));
    }

    private static String blankToNull(String s) {
        return s == null || s.isBlank() ? null : s.trim();
    }
}
