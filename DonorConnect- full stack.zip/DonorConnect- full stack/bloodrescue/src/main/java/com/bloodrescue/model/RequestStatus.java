package com.bloodrescue.model;

/**
 * Life cycle of a blood request:
 * PENDING (visible to matching donors) -> (donor accepts) ACCEPTED -> (donation confirmed) FULFILLED
 * Admin may REJECT a request or fulfil it directly from blood-bank stock.
 * The requester may CANCEL while it is PENDING or ACCEPTED.
 */
public enum RequestStatus {
    PENDING, ACCEPTED, FULFILLED, REJECTED, CANCELLED
}
