package com.bloodrescue.repository;

import com.bloodrescue.model.BloodRequest;
import com.bloodrescue.model.RequestStatus;
import com.bloodrescue.model.Urgency;
import com.bloodrescue.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface BloodRequestRepository extends JpaRepository<BloodRequest, Long> {

    List<BloodRequest> findByRequesterOrderByCreatedAtDesc(User requester);

    List<BloodRequest> findAllByOrderByCreatedAtDesc();

    List<BloodRequest> findByStatusOrderByCreatedAtDesc(RequestStatus status);

    List<BloodRequest> findByStatusAndBloodGroupIn(RequestStatus status, Collection<String> bloodGroups);

    List<BloodRequest> findByAcceptedByOrderByUpdatedAtDesc(User donor);

    /** Every request a donor has ever accepted (the donor history shown to the admin). */
    List<BloodRequest> findByAcceptedByIsNotNullOrderByUpdatedAtDesc();

    List<BloodRequest> findByAcceptedByAndStatus(User donor, RequestStatus status);

    boolean existsByAcceptedByAndStatus(User donor, RequestStatus status);

    long countByStatus(RequestStatus status);

    long countByStatusAndUrgency(RequestStatus status, Urgency urgency);
}
