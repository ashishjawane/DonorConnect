package com.bloodrescue.dto;

import com.bloodrescue.model.Urgency;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

/** All request/response objects in one file (Java records). */
public final class Dtos {

    private Dtos() {
    }

    // ------------------------------------------------------------------ requests (input)

    public record RegisterRequest(
            @NotBlank(message = "Name is required") @Size(max = 100, message = "Name is too long") String name,
            @NotBlank(message = "Email is required") @Email(message = "Enter a valid email") @Size(max = 150) String email,
            @NotBlank(message = "Password is required") @Size(min = 6, max = 60, message = "Password must be 6 to 60 characters") String password,
            @NotBlank(message = "Phone is required") @Pattern(regexp = "\\d{10}", message = "Phone must be 10 digits") String phone,
            @NotBlank(message = "City is required") @Size(max = 80) String city,
            String bloodGroup,
            @NotBlank(message = "Role is required") String role) {
    }

    public record LoginRequest(
            @NotBlank(message = "Email is required") String email,
            @NotBlank(message = "Password is required") String password,
            @NotBlank(message = "Choose an account type") String role) {
    }

    public record ProfileUpdate(
            @NotBlank(message = "Name is required") @Size(max = 100) String name,
            @NotBlank(message = "Phone is required") @Pattern(regexp = "\\d{10}", message = "Phone must be 10 digits") String phone,
            @NotBlank(message = "City is required") @Size(max = 80) String city,
            String bloodGroup) {
    }

    public record PasswordChange(
            @NotBlank(message = "Current password is required") String currentPassword,
            @NotBlank(message = "New password is required") @Size(min = 6, max = 60, message = "New password must be 6 to 60 characters") String newPassword) {
    }

    public record BloodRequestForm(
            @NotBlank(message = "Patient name is required") @Size(max = 100) String patientName,
            @NotBlank(message = "Blood group is required") String bloodGroup,
            @Min(value = 1, message = "Units must be at least 1") @Max(value = 10, message = "Units cannot be more than 10") int units,
            @NotBlank(message = "Hospital is required") @Size(max = 150) String hospital,
            @NotBlank(message = "City is required") @Size(max = 80) String city,
            @NotNull(message = "Urgency is required") Urgency urgency,
            @NotNull(message = "Required date is required") LocalDate requiredDate,
            @Size(max = 500, message = "Note can be at most 500 characters") String note) {
    }

    public record NoteBody(@Size(max = 500, message = "Note can be at most 500 characters") String note) {
    }

    public record AvailabilityBody(boolean available) {
    }

    public record StatusBody(boolean active) {
    }

    public record StockUpdate(
            @Min(value = 0, message = "Units cannot be negative") @Max(value = 100000, message = "Units value is too large") int units) {
    }

    // ------------------------------------------------------------------ responses (output)

    public record UserDto(
            Long id, String name, String email, String phone, String city, String bloodGroup,
            String role, boolean active, boolean available, LocalDate lastDonationDate,
            int totalDonations, LocalDateTime createdAt) {
    }

    public record RequestDto(
            Long id, String patientName, String bloodGroup, int units, String hospital, String city,
            String urgency, LocalDate requiredDate, String note, String status, String adminNote,
            boolean fulfilledFromStock, LocalDateTime createdAt, LocalDateTime updatedAt,
            String requesterName, String requesterPhone, String requesterEmail,
            String donorName, String donorPhone, String donorBloodGroup) {
    }

    public record StockDto(String bloodGroup, int units) {
    }

    public record AdminStats(
            long totalRequesters, long totalDonors, long availableDonors,
            long totalRequests, long pending, long accepted, long fulfilled,
            long rejected, long cancelled, long criticalOpen,
            long totalStockUnits, List<StockDto> stock) {
    }

    public record PublicStats(long donors, long fulfilled, long requests) {
    }

    public record DonorStats(
            String bloodGroup, boolean available, int totalDonations, LocalDate lastDonationDate,
            boolean eligible, LocalDate nextEligibleDate, long matchingOpenRequests, boolean hasActiveRequest) {
    }
}
