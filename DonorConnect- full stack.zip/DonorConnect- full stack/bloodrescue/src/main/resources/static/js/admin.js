/* Admin (blood management team) dashboard */
let me = null;
let allRequests = [];
let donationList = [];
let userList = [];
let donorList = [];

(async function () {
  me = await initDashboard('ADMIN');
  if (!me) return;

  document.getElementById('statusFilter').addEventListener('change', renderRequests);
  document.getElementById('donationSearch').addEventListener('input', renderDonations);
  document.getElementById('userSearch').addEventListener('input', function () { renderPeople('USER'); });
  document.getElementById('donorSearch').addEventListener('input', function () { renderPeople('DONOR'); });

  document.getElementById('requestRows').addEventListener('click', onRequestAction);
  document.getElementById('userRows').addEventListener('click', onUserAction);
  document.getElementById('donorRows').addEventListener('click', onUserAction);
  document.getElementById('stockGrid').addEventListener('click', onStockSave);

  renderProfile(document.getElementById('profileMount'), me, { bloodGroup: false });
  await refreshAll();
  connectLive(debounce(refreshAll, 300));   // real-time: any request / registration change reloads the tables
})();

async function refreshAll() {
  try {
    const r = await Promise.all([
      api('/api/admin/stats'),
      api('/api/admin/requests?status=ALL'),
      api('/api/admin/donations'),
      api('/api/admin/users?role=USER'),
      api('/api/admin/users?role=DONOR'),
      api('/api/admin/stock')
    ]);
    allRequests = r[1];
    donationList = r[2];
    userList = r[3];
    donorList = r[4];
    renderStats(r[0]);
    renderRecent();
    renderRequests();
    renderDonations();
    renderPeople('USER');
    renderPeople('DONOR');
    renderStock(r[5]);
  } catch (e) {
    toast(e.message, 'err');
  }
}

/* ------------------------------------------------------------------ home */

function renderStats(s) {
  document.getElementById('stats').innerHTML =
    statCard('Users', s.totalRequesters) +
    statCard('Donors', s.totalDonors + ' (' + s.availableDonors + ' available)', 'green') +
    statCard('Total requests', s.totalRequests) +
    statCard('Waiting for donor', s.pending, 'amber') +
    statCard('Critical & waiting', s.criticalOpen, 'amber') +
    statCard('Accepted', s.accepted, 'blue') +
    statCard('Fulfilled', s.fulfilled, 'green') +
    statCard('Units in stock', s.totalStockUnits, 'green');
}

function renderRecent() {
  const box = document.getElementById('recent');
  if (!allRequests.length) {
    box.innerHTML = '<div class="empty">No requests yet.</div>';
    return;
  }
  box.innerHTML = allRequests.slice(0, 6).map(function (r) {
    return '<div class="recent-item"><div>' + bloodChip(r.bloodGroup) + ' <b>' + esc(r.patientName) + '</b> ' + urgencyBadge(r.urgency) +
      '<div class="small">' + esc(r.hospital) + ' · ' + fmtDateTime(r.createdAt) + '</div></div>' +
      statusBadge(r.status) + '</div>';
  }).join('');
}

function renderStock(stock) {
  const grid = document.getElementById('stockGrid');
  if (grid.contains(document.activeElement)) return;   // do not wipe a number the admin is typing
  grid.innerHTML = stock.map(function (s) {
    return '<div class="stock-card"><div class="head">' + bloodChip(s.bloodGroup) + '<span class="small">units</span></div>' +
      '<input type="number" min="0" max="100000" value="' + esc(s.units) + '" data-input="' + esc(s.bloodGroup) + '">' +
      '<button class="btn btn-primary btn-sm" data-save="' + esc(s.bloodGroup) + '">Save</button></div>';
  }).join('');
}

async function onStockSave(ev) {
  const btn = ev.target.closest('[data-save]');
  if (!btn) return;
  const group = btn.dataset.save;
  const units = parseInt(document.querySelector('[data-input="' + group + '"]').value, 10);
  if (isNaN(units) || units < 0) {
    toast('Enter a valid number of units', 'err');
    return;
  }
  const ok = await act(function () {
    return api('/api/admin/stock/' + encodeURIComponent(group), 'PUT', { units: units });
  }, 'Stock for ' + group + ' updated');
  if (ok) {
    document.activeElement.blur();
    await refreshAll();
  }
}

/* ------------------------------------------------------------------ user requests */

function renderRequests() {
  const filter = document.getElementById('statusFilter').value;
  const list = allRequests.filter(function (r) { return filter === 'ALL' || r.status === filter; });
  const body = document.getElementById('requestRows');
  if (!list.length) {
    body.innerHTML = '<tr><td colspan="10" class="empty">No requests found.</td></tr>';
    return;
  }
  body.innerHTML = list.map(function (r) {
    let actions = '';
    if (r.status === 'PENDING') {
      actions += '<button class="btn btn-light btn-sm" data-act="stock" data-id="' + r.id + '">Fulfil from stock</button>';
    }
    if (r.status === 'ACCEPTED') {
      actions += '<button class="btn btn-green btn-sm" data-act="fulfill" data-id="' + r.id + '">Mark fulfilled</button>';
    }
    if (r.status === 'PENDING' || r.status === 'ACCEPTED') {
      actions += '<button class="btn btn-danger btn-sm" data-act="reject" data-id="' + r.id + '">Reject</button>';
    }
    const donor = r.donorName
      ? esc(r.donorName) + '<div class="small">' + esc(r.donorPhone || '') + '</div>'
      : (r.fulfilledFromStock ? '<span class="small">Blood-bank stock</span>' : '<span class="muted">—</span>');
    return '<tr>' +
      '<td>' + r.id + '</td>' +
      '<td><b>' + esc(r.patientName) + '</b><div class="small">by ' + esc(r.requesterName) + ' · ' + esc(r.requesterPhone || '') + '</div>' +
      (r.note ? '<div class="small">“' + esc(r.note) + '”</div>' : '') +
      (r.adminNote ? '<div class="small"><b>Admin:</b> ' + esc(r.adminNote) + '</div>' : '') + '</td>' +
      '<td>' + bloodChip(r.bloodGroup) + '</td>' +
      '<td>' + esc(r.units) + '</td>' +
      '<td>' + esc(r.hospital) + '<div class="small">' + esc(r.city) + '</div></td>' +
      '<td>' + urgencyBadge(r.urgency) + '</td>' +
      '<td>' + fmtDate(r.requiredDate) + '</td>' +
      '<td>' + statusBadge(r.status) + '</td>' +
      '<td>' + donor + '</td>' +
      '<td><div class="actions">' + actions + '</div></td>' +
      '</tr>';
  }).join('');
}

async function onRequestAction(ev) {
  const btn = ev.target.closest('[data-act]');
  if (!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.act;
  let ok = false;

  if (action === 'reject') {
    const reason = prompt('Reason for rejecting this request (shown to the requester):');
    if (reason === null) return;
    ok = await act(function () { return api('/api/admin/requests/' + id + '/reject', 'POST', { note: reason }); }, 'Request rejected');
  } else if (action === 'stock') {
    if (!confirm('Fulfil this request from blood-bank stock? The stock will be reduced.')) return;
    ok = await act(function () { return api('/api/admin/requests/' + id + '/fulfill-from-stock', 'POST'); }, 'Fulfilled from stock');
  } else if (action === 'fulfill') {
    if (!confirm('Confirm that the donor has donated for this request?')) return;
    ok = await act(function () { return api('/api/admin/requests/' + id + '/fulfill', 'POST'); }, 'Marked as fulfilled');
  }
  if (ok) await refreshAll();
}

/* ------------------------------------------------------------------ donor history */

function renderDonations() {
  const term = document.getElementById('donationSearch').value.trim().toLowerCase();
  const list = donationList.filter(function (r) {
    return !term || [r.donorName, r.patientName, r.hospital, r.bloodGroup, r.donorBloodGroup, r.requesterName].some(function (v) {
      return v && String(v).toLowerCase().indexOf(term) !== -1;
    });
  });
  const body = document.getElementById('donationRows');
  if (!list.length) {
    body.innerHTML = '<tr><td colspan="8" class="empty">No donor activity yet.</td></tr>';
    return;
  }
  body.innerHTML = list.map(function (r) {
    return '<tr>' +
      '<td>' + fmtDateTime(r.updatedAt) + '</td>' +
      '<td><b>' + esc(r.donorName) + '</b><div class="small">' + esc(r.donorPhone || '') + '</div></td>' +
      '<td>' + bloodChip(r.donorBloodGroup) + '</td>' +
      '<td>' + esc(r.patientName) + '</td>' +
      '<td>' + bloodChip(r.bloodGroup) + ' <span class="small">' + esc(r.units) + ' unit(s)</span></td>' +
      '<td>' + esc(r.hospital) + '<div class="small">' + esc(r.city) + '</div></td>' +
      '<td>' + esc(r.requesterName) + '<div class="small">' + esc(r.requesterPhone || '') + '</div></td>' +
      '<td>' + statusBadge(r.status) + '</td>' +
      '</tr>';
  }).join('');
}

/* ------------------------------------------------------------------ manage users and donors */

function renderPeople(role) {
  const isDonor = role === 'DONOR';
  const list = isDonor ? donorList : userList;
  const term = document.getElementById(isDonor ? 'donorSearch' : 'userSearch').value.trim().toLowerCase();
  const rows = list.filter(function (u) {
    return !term || [u.name, u.email, u.city, u.bloodGroup, u.phone].some(function (v) {
      return v && String(v).toLowerCase().indexOf(term) !== -1;
    });
  });
  const body = document.getElementById(isDonor ? 'donorRows' : 'userRows');
  const cols = isDonor ? 8 : 7;
  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="' + cols + '" class="empty">' + (isDonor ? 'No donors found.' : 'No users found.') + '</td></tr>';
    return;
  }
  body.innerHTML = rows.map(function (u) {
    const account = '<span class="badge s-' + (u.active ? 'ACTIVE' : 'INACTIVE') + '">' + (u.active ? 'Active' : 'Deactivated') + '</span>' +
      (isDonor ? '<div class="small">' + (u.available ? 'Available' : 'Not available') + '</div>' : '');
    const action = '<button class="btn ' + (u.active ? 'btn-danger' : 'btn-green') + ' btn-sm" data-user="' + u.id + '" data-active="' + (!u.active) + '">' +
      (u.active ? 'Deactivate' : 'Activate') + '</button>';
    return '<tr>' +
      '<td><b>' + esc(u.name) + '</b></td>' +
      '<td>' + esc(u.email) + '<div class="small">' + esc(u.phone || '') + '</div></td>' +
      '<td>' + esc(u.city || '') + '</td>' +
      '<td>' + (u.bloodGroup ? bloodChip(u.bloodGroup) : '<span class="muted">—</span>') + '</td>' +
      '<td>' + account + '</td>' +
      (isDonor ? '<td>' + esc(u.totalDonations) + '<div class="small">last: ' + fmtDate(u.lastDonationDate) + '</div></td>' : '') +
      '<td>' + fmtDate(u.createdAt) + '</td>' +
      '<td>' + action + '</td>' +
      '</tr>';
  }).join('');
}

async function onUserAction(ev) {
  const btn = ev.target.closest('[data-user]');
  if (!btn) return;
  const makeActive = btn.dataset.active === 'true';
  if (!makeActive && !confirm('Deactivate this account? They will no longer be able to log in.')) return;
  const ok = await act(function () {
    return api('/api/admin/users/' + btn.dataset.user + '/status', 'PATCH', { active: makeActive });
  }, makeActive ? 'Account activated' : 'Account deactivated');
  if (ok) await refreshAll();
}
