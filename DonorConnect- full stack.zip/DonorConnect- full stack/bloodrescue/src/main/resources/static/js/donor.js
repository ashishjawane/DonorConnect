/* Donor dashboard */
let me = null;
let stats = null;
let openRequests = [];
let donations = [];

(async function () {
  me = await initDashboard('DONOR');
  if (!me) return;

  document.getElementById('welcome').textContent = 'Welcome, ' + me.name;

  document.getElementById('availableToggle').addEventListener('change', async function (ev) {
    const checkbox = ev.target;
    const ok = await act(function () { return api('/api/donor/availability', 'PUT', { available: checkbox.checked }); },
      checkbox.checked ? 'You are now available' : 'You are now unavailable');
    if (!ok) checkbox.checked = !checkbox.checked;
    await refresh();
  });

  document.getElementById('openList').addEventListener('click', function (ev) {
    const acceptBtn = ev.target.closest('[data-accept]');
    if (acceptBtn) accept(acceptBtn.dataset.accept);
    const rejectBtn = ev.target.closest('[data-reject]');
    if (rejectBtn) reject(rejectBtn.dataset.reject);
  });
  document.getElementById('historyRows').addEventListener('click', function (ev) {
    const done = ev.target.closest('[data-complete]');
    if (done) complete(done.dataset.complete);
    const rel = ev.target.closest('[data-release]');
    if (rel) release(rel.dataset.release);
  });

  renderProfile(document.getElementById('profileMount'), me, { bloodGroup: true, onSaved: function () { refresh(); } });
  await refresh();
  connectLive(debounce(refresh, 250));   // real-time: new requests appear, taken requests disappear
})();

async function refresh() {
  try {
    const results = await Promise.all([
      api('/api/donor/stats'), api('/api/donor/requests/open'), api('/api/donor/requests/mine')
    ]);
    stats = results[0];
    openRequests = results[1];
    donations = results[2];
    renderOverview();
    renderHomeOpen();
    renderOpen();
    renderHistory();
  } catch (e) {
    toast(e.message, 'err');
  }
}

function canAccept() {
  return stats && stats.available && stats.eligible && !stats.hasActiveRequest;
}

function renderOverview() {
  const notice = document.getElementById('notice');
  let msg = '';
  if (!stats.eligible) msg = 'You donated recently. You can donate again on ' + fmtDate(stats.nextEligibleDate) + '.';
  else if (!stats.available) msg = 'You are marked as unavailable. Turn availability on to accept requests.';
  else if (stats.hasActiveRequest) msg = 'You have an accepted request. Open History to mark it donated or withdraw.';
  notice.innerHTML = msg ? '<div class="notice">' + esc(msg) + '</div>' : '';

  document.getElementById('stats').innerHTML =
    statCard('Your blood group', stats.bloodGroup || '—') +
    statCard('Total donations', stats.totalDonations, 'green') +
    statCard('Last donation', fmtDate(stats.lastDonationDate), 'blue') +
    statCard('Eligible to donate', stats.eligible ? 'Yes' : 'From ' + fmtDate(stats.nextEligibleDate), stats.eligible ? 'green' : 'amber') +
    statCard('Open requests for you', stats.matchingOpenRequests, 'amber');

  document.getElementById('availableToggle').checked = stats.available;
  document.getElementById('availableText').textContent = stats.available ? 'Available to donate' : 'Not available';
}

function renderHomeOpen() {
  const box = document.getElementById('homeOpen');
  if (!stats.bloodGroup) {
    box.innerHTML = '<div class="empty">Add your blood group in Profile to see matching requests.</div>';
    return;
  }
  if (!openRequests.length) {
    box.innerHTML = '<div class="empty">No open requests right now. Thank you for being ready!</div>';
    return;
  }
  box.innerHTML = openRequests.slice(0, 3).map(function (r) {
    return '<div class="recent-item"><div>' + bloodChip(r.bloodGroup) + ' <b>' + esc(r.patientName) + '</b>' +
      '<div class="small">' + esc(r.hospital) + ', ' + esc(r.city) + '</div></div>' + urgencyBadge(r.urgency) + '</div>';
  }).join('');
}

function renderOpen() {
  const box = document.getElementById('openList');
  if (!stats.bloodGroup) {
    box.innerHTML = '<div class="panel empty">Add your blood group in Profile to see matching requests.</div>';
    return;
  }
  if (!openRequests.length) {
    box.innerHTML = '<div class="panel empty">No open requests match your blood group right now.</div>';
    return;
  }
  const allowed = canAccept();
  box.innerHTML = openRequests.map(function (r) {
    return '<div class="req-card ' + (r.urgency === 'CRITICAL' ? 'critical' : '') + '">' +
      '<div class="row">' + bloodChip(r.bloodGroup) + urgencyBadge(r.urgency) + '</div>' +
      '<div><b>' + esc(r.patientName) + '</b> needs <b>' + esc(r.units) + '</b> unit(s)</div>' +
      '<div>🏥 ' + esc(r.hospital) + ', ' + esc(r.city) + '</div>' +
      '<div>📅 Needed by ' + fmtDate(r.requiredDate) + '</div>' +
      (r.note ? '<div class="small">“' + esc(r.note) + '”</div>' : '') +
      '<div class="small">Requested by ' + esc(r.requesterName) + ' · ' + fmtDateTime(r.createdAt) + '</div>' +
      '<div class="actions">' +
      '<button class="btn btn-primary" data-accept="' + r.id + '"' + (allowed ? '' : ' disabled') + '>Accept</button>' +
      '<button class="btn btn-danger" data-reject="' + r.id + '">Reject</button>' +
      '</div></div>';
  }).join('');
}

function renderHistory() {
  const body = document.getElementById('historyRows');
  if (!donations.length) {
    body.innerHTML = '<tr><td colspan="7" class="empty">You have not accepted any request yet.</td></tr>';
    return;
  }
  body.innerHTML = donations.map(function (r) {
    const active = r.status === 'ACCEPTED';
    return '<tr>' +
      '<td><b>' + esc(r.patientName) + '</b></td>' +
      '<td>' + bloodChip(r.bloodGroup) + '</td>' +
      '<td>' + esc(r.hospital) + '<div class="small">' + esc(r.city) + '</div></td>' +
      '<td>' + fmtDate(r.requiredDate) + '</td>' +
      '<td>' + statusBadge(r.status) + '</td>' +
      '<td>' + (r.requesterPhone ? esc(r.requesterName) + '<br>📞 ' + esc(r.requesterPhone) : esc(r.requesterName)) + '</td>' +
      '<td>' + (active
        ? '<div class="actions"><button class="btn btn-green btn-sm" data-complete="' + r.id + '">Mark donated</button>' +
          '<button class="btn btn-danger btn-sm" data-release="' + r.id + '">Withdraw</button></div>'
        : '') + '</td>' +
      '</tr>';
  }).join('');
}

async function accept(id) {
  if (!confirm('Accept this request? The requester will see your name and phone number.')) return;
  const ok = await act(function () { return api('/api/donor/requests/' + id + '/accept', 'POST'); },
    'Request accepted. Contact details are in History.');
  await refresh();
  if (ok) showSection('history');
}

async function reject(id) {
  if (!confirm('Reject this request? It will be hidden from your list (other donors still see it).')) return;
  await act(function () { return api('/api/donor/requests/' + id + '/reject', 'POST'); }, 'Request rejected');
  await refresh();
}

async function complete(id) {
  if (!confirm('Confirm that you have donated blood for this request?')) return;
  await act(function () { return api('/api/donor/requests/' + id + '/complete', 'POST'); }, 'Donation recorded. Thank you for saving a life!');
  await refresh();
}

async function release(id) {
  if (!confirm('Withdraw from this request? It will become available to other donors.')) return;
  await act(function () { return api('/api/donor/requests/' + id + '/release', 'POST'); }, 'You withdrew from the request');
  await refresh();
}
