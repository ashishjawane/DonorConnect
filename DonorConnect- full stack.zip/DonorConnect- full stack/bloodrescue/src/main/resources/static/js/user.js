/* User (requester) dashboard */
let me = null;
let requests = [];

(async function () {
  me = await initDashboard('USER');
  if (!me) return;

  document.getElementById('welcome').textContent = 'Welcome, ' + me.name;

  const form = document.getElementById('requestForm');
  fillBloodGroups(form.elements['bloodGroup'], 'Select blood group');
  const dateInput = form.elements['requiredDate'];
  dateInput.min = todayStr();
  dateInput.value = todayStr();
  form.elements['city'].value = me.city || '';
  form.addEventListener('submit', submitRequest);

  document.getElementById('requestRows').addEventListener('click', function (ev) {
    const btn = ev.target.closest('[data-cancel]');
    if (btn) cancelRequest(btn.dataset.cancel);
  });

  renderProfile(document.getElementById('profileMount'), me, { bloodGroup: true });
  await loadRequests();
  connectLive(debounce(loadRequests, 250));   // real-time: reload when a donor / admin changes something
})();

async function loadRequests() {
  try {
    requests = await api('/api/user/requests');
    renderStats();
    renderRecent();
    renderTable();
  } catch (e) {
    toast(e.message, 'err');
  }
}

async function submitRequest(ev) {
  ev.preventDefault();
  const f = ev.target;
  const body = {
    patientName: f.elements['patientName'].value,
    bloodGroup: f.elements['bloodGroup'].value,
    units: Number(f.elements['units'].value),
    hospital: f.elements['hospital'].value,
    city: f.elements['city'].value,
    urgency: f.elements['urgency'].value,
    requiredDate: f.elements['requiredDate'].value,
    note: f.elements['note'].value
  };
  const ok = await act(function () { return api('/api/user/requests', 'POST', body); },
    'Request sent. Matching donors have been notified.');
  if (ok) {
    f.reset();
    f.elements['requiredDate'].value = todayStr();
    f.elements['city'].value = me.city || '';
    await loadRequests();
    showSection('history');
  }
}

async function cancelRequest(id) {
  if (!confirm('Cancel this blood request?')) return;
  const ok = await act(function () { return api('/api/user/requests/' + id + '/cancel', 'POST'); }, 'Request cancelled');
  if (ok) await loadRequests();
}

function renderStats() {
  const count = function (s) { return requests.filter(function (r) { return r.status === s; }).length; };
  document.getElementById('stats').innerHTML =
    statCard('Total requests', requests.length) +
    statCard('Waiting for a donor', count('PENDING'), 'amber') +
    statCard('Donor found', count('ACCEPTED'), 'blue') +
    statCard('Fulfilled', count('FULFILLED'), 'green');
}

function renderRecent() {
  const box = document.getElementById('recent');
  if (!requests.length) {
    box.innerHTML = '<div class="empty">No requests yet.</div>';
    return;
  }
  box.innerHTML = requests.slice(0, 5).map(function (r) {
    return '<div class="recent-item"><div>' + bloodChip(r.bloodGroup) + ' <b>' + esc(r.patientName) + '</b>' +
      '<div class="small">' + esc(r.hospital) + ' · ' + fmtDateTime(r.createdAt) + '</div></div>' +
      statusBadge(r.status) + '</div>';
  }).join('');
}

function details(r) {
  const parts = [];
  if (r.donorName) {
    parts.push('<div><b>Donor:</b> ' + esc(r.donorName) + (r.donorBloodGroup ? ' (' + esc(r.donorBloodGroup) + ')' : '') +
      (r.donorPhone ? '<br>📞 ' + esc(r.donorPhone) : '') + '</div>');
  }
  if (r.fulfilledFromStock) parts.push('<div class="small">Supplied from blood-bank stock</div>');
  if (r.adminNote) parts.push('<div class="small"><b>Admin:</b> ' + esc(r.adminNote) + '</div>');
  if (r.note) parts.push('<div class="small">Your note: ' + esc(r.note) + '</div>');
  return parts.join('') || '<span class="muted">—</span>';
}

function renderTable() {
  const body = document.getElementById('requestRows');
  if (!requests.length) {
    body.innerHTML = '<tr><td colspan="9" class="empty">You have not requested blood yet.</td></tr>';
    return;
  }
  body.innerHTML = requests.map(function (r) {
    const canCancel = r.status === 'PENDING' || r.status === 'ACCEPTED';
    return '<tr>' +
      '<td><b>' + esc(r.patientName) + '</b><div class="small">' + fmtDateTime(r.createdAt) + '</div></td>' +
      '<td>' + bloodChip(r.bloodGroup) + '</td>' +
      '<td>' + esc(r.units) + '</td>' +
      '<td>' + esc(r.hospital) + '<div class="small">' + esc(r.city) + '</div></td>' +
      '<td>' + urgencyBadge(r.urgency) + '</td>' +
      '<td>' + fmtDate(r.requiredDate) + '</td>' +
      '<td>' + statusBadge(r.status) + '</td>' +
      '<td>' + details(r) + '</td>' +
      '<td>' + (canCancel ? '<button class="btn btn-danger btn-sm" data-cancel="' + r.id + '">Cancel</button>' : '') + '</td>' +
      '</tr>';
  }).join('');
}
