/* Shared helpers used by every page. */

const BLOOD_GROUPS = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
const DASHBOARDS = { USER: 'user.html', DONOR: 'donor.html', ADMIN: 'admin.html' };

/** Calls the backend. Throws an Error with the server's message when the call fails. */
async function api(path, method, body) {
  const opts = { method: method || 'GET', credentials: 'same-origin', headers: {} };
  if (body !== undefined) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(path, opts);
  const text = await res.text();
  let data = null;
  if (text) {
    try { data = JSON.parse(text); } catch (e) { data = null; }
  }
  if (!res.ok) {
    const onDashboard = document.body.dataset.protected === 'true';
    const loginPage = document.body.dataset.login || 'login.html';
    if (res.status === 401 && onDashboard) {
      location.href = loginPage;
    }
    // 403 WRONG_ROLE: all tabs of one browser share one login, so another tab signed in as a different account
    if (res.status === 403 && onDashboard && data && data.code === 'WRONG_ROLE') {
      toast(data.message, 'err');
      setTimeout(function () { location.href = loginPage; }, 1800);
    }
    const err = new Error((data && data.message) || ('Request failed (' + res.status + ')'));
    err.status = res.status;
    throw err;
  }
  return data;
}

/** Runs an async action and shows a toast for success / failure. Returns true when it worked. */
async function act(fn, okMessage) {
  try {
    await fn();
    if (okMessage) toast(okMessage, 'ok');
    return true;
  } catch (e) {
    toast(e.message, 'err');
    return false;
  }
}

/** Escapes text before putting it into innerHTML (prevents XSS). */
function esc(value) {
  return String(value === null || value === undefined ? '' : value).replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}

function toast(message, type) {
  let box = document.getElementById('toast-box');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toast-box';
    document.body.appendChild(box);
  }
  const el = document.createElement('div');
  el.className = 'toast ' + (type || 'ok');
  el.textContent = message;
  box.appendChild(el);
  setTimeout(function () { el.remove(); }, 3800);
}

function parseDate(v) {
  if (!v) return null;
  return new Date(String(v).length === 10 ? v + 'T00:00:00' : v);
}
function fmtDate(v) {
  const d = parseDate(v);
  return d ? d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }) : '—';
}
function fmtDateTime(v) {
  const d = parseDate(v);
  return d ? d.toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
}
function todayStr() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function fillBloodGroups(select, blankLabel) {
  let html = blankLabel ? '<option value="">' + esc(blankLabel) + '</option>' : '';
  BLOOD_GROUPS.forEach(function (g) { html += '<option value="' + g + '">' + g + '</option>'; });
  select.innerHTML = html;
}

function statusBadge(status) { return '<span class="badge s-' + esc(status) + '">' + esc(status) + '</span>'; }
function urgencyBadge(u) { return '<span class="badge u-' + esc(u) + '">' + esc(u) + '</span>'; }
function bloodChip(g) { return '<span class="bg-chip">' + esc(g || '—') + '</span>'; }
function statCard(label, value, cls) {
  return '<div class="stat ' + (cls || '') + '"><div class="num">' + esc(value) + '</div><div class="lbl">' + esc(label) + '</div></div>';
}

/* ---------- dashboard shell ---------- */

function showSection(id) {
  const sections = Array.prototype.slice.call(document.querySelectorAll('.section'));
  if (!sections.some(function (s) { return s.id === id; })) id = sections[0].id;
  sections.forEach(function (s) { s.hidden = s.id !== id; });
  document.querySelectorAll('[data-section]').forEach(function (a) {
    a.classList.toggle('active', a.dataset.section === id);
  });
  history.replaceState(null, '', '#' + id);
}

/** Checks the login, enforces the role, wires logout + sidebar. Returns the user or null (redirecting). */
async function initDashboard(role) {
  let me;
  try {
    me = await api('/api/auth/me');
  } catch (e) {
    return null;   // api() already redirected to the login page
  }
  if (me.role !== role) {
    location.href = DASHBOARDS[me.role];
    return null;
  }
  document.getElementById('whoName').textContent = me.name;
  window.currentRole = me.role;
  document.getElementById('logoutBtn').addEventListener('click', async function () {
    try { await api('/api/auth/logout', 'POST'); } catch (e) { /* ignore */ }
    location.href = document.body.dataset.login || 'login.html';
  });
  document.querySelectorAll('[data-section]').forEach(function (a) {
    a.addEventListener('click', function (ev) { ev.preventDefault(); showSection(a.dataset.section); });
  });
  showSection(location.hash.slice(1));
  return me;
}

/** Profile + change password forms, identical for all three roles. */
function renderProfile(mount, me, options) {
  const withGroup = !!(options && options.bloodGroup);
  mount.innerHTML =
    '<div class="grid-2">' +
    '<div class="panel"><h3>My details</h3>' +
    '<form id="profileForm" class="form-grid">' +
    '<label>Full name<input name="name" required maxlength="100"></label>' +
    '<label>Email<input name="email" disabled></label>' +
    '<label>Phone (10 digits)<input name="phone" required pattern="[0-9]{10}" maxlength="10"></label>' +
    '<label>City<input name="city" required maxlength="80"></label>' +
    (withGroup ? '<label>Blood group<select name="bloodGroup"></select></label>' : '') +
    '<button class="btn btn-primary" type="submit">Save changes</button>' +
    '</form></div>' +
    '<div class="panel"><h3>Change password</h3>' +
    '<form id="passwordForm" class="form-grid">' +
    '<label class="full">Current password<input type="password" name="currentPassword" required></label>' +
    '<label class="full">New password (min 6 characters)<input type="password" name="newPassword" required minlength="6" maxlength="60"></label>' +
    '<button class="btn btn-primary" type="submit">Update password</button>' +
    '</form></div></div>';

  const pf = mount.querySelector('#profileForm');
  pf.elements['name'].value = me.name || '';
  pf.email.value = me.email || '';
  pf.phone.value = me.phone || '';
  pf.city.value = me.city || '';
  if (withGroup) {
    fillBloodGroups(pf.bloodGroup, me.role === 'DONOR' ? 'Select blood group' : 'Not sure / not set');
    pf.bloodGroup.value = me.bloodGroup || '';
  }

  pf.addEventListener('submit', async function (ev) {
    ev.preventDefault();
    const body = { name: pf.elements['name'].value, phone: pf.phone.value, city: pf.city.value, bloodGroup: withGroup ? pf.bloodGroup.value : null };
    await act(async function () {
      const updated = await api('/api/profile', 'PUT', body);
      Object.assign(me, updated);
      document.getElementById('whoName').textContent = updated.name;
      if (options && options.onSaved) options.onSaved(updated);
    }, 'Profile updated');
  });

  const pw = mount.querySelector('#passwordForm');
  pw.addEventListener('submit', async function (ev) {
    ev.preventDefault();
    const ok = await act(function () {
      return api('/api/profile/password', 'POST', { currentPassword: pw.currentPassword.value, newPassword: pw.newPassword.value });
    }, 'Password changed');
    if (ok) pw.reset();
  });
}

/* ---------- real-time updates (Server-Sent Events) ---------- */

function debounce(fn, ms) {
  let timer = null;
  return function () {
    const args = arguments;
    clearTimeout(timer);
    timer = setTimeout(function () { fn.apply(null, args); }, ms);
  };
}

/**
 * Opens the live connection. The server pushes an "update" message whenever something that concerns this
 * user changes (new request, request accepted, ...). We show the message as a notification and call onUpdate
 * so the page reloads its data.
 */
function connectLive(onUpdate) {
  if (!window.EventSource) return;
  const dot = document.getElementById('liveDot');
  const source = new EventSource('/api/events');
  let firstConnect = true;

  source.addEventListener('ready', function () {
    if (dot) dot.classList.add('on');
    // after a dropped connection we may have missed something, so reload once on reconnect
    if (!firstConnect) onUpdate({});
    firstConnect = false;
  });
  source.addEventListener('update', function (ev) {
    let data = {};
    try { data = JSON.parse(ev.data); } catch (e) { data = {}; }
    if (data.message) toast(data.message, 'info');
    onUpdate(data);
  });
  source.onerror = function () {
    if (dot) dot.classList.remove('on');   // the browser reconnects automatically
    // if the login in this browser now belongs to another account type, go back to the login page
    api('/api/auth/me').then(function (u) {
      if (window.currentRole && u.role !== window.currentRole) {
        location.href = document.body.dataset.login || 'login.html';
      }
    }).catch(function () { });
  };
}
