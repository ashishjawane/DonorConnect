package com.bloodrescue;

import com.bloodrescue.model.BloodGroups;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BloodGroupsTest {

    @Test
    void oNegativeIsUniversalDonor() {
        for (String recipient : BloodGroups.ALL) {
            assertTrue(BloodGroups.canDonate("O-", recipient));
        }
    }

    @Test
    void abPositiveReceivesFromEveryone() {
        for (String donor : BloodGroups.ALL) {
            assertTrue(BloodGroups.canDonate(donor, "AB+"));
        }
    }

    @Test
    void positiveCannotGiveToNegative() {
        assertFalse(BloodGroups.canDonate("O+", "A-"));
        assertFalse(BloodGroups.canDonate("A+", "A-"));
    }

    @Test
    void oPositiveRecipients() {
        assertEquals(Set.of("O+", "A+", "B+", "AB+"), BloodGroups.recipientsFor("O+"));
    }

    @Test
    void validatesGroupNames() {
        assertTrue(BloodGroups.isValid("AB-"));
        assertFalse(BloodGroups.isValid("C+"));
        assertFalse(BloodGroups.isValid(null));
    }
}
