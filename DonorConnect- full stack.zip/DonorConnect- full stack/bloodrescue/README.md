# BloodRescue – Blood Donation & Request Management

Full-stack project: **Java 17 + Spring Boot 3 + Spring Security + JPA/Hibernate + MySQL** (backend) and plain
**HTML + CSS + JavaScript** (frontend, served by Spring Boot itself – one app, one port).
Updates are **real-time** (Server-Sent Events): nobody has to refresh a page.

## Pages

| Page | Who | Purpose |
|------|-----|---------|
| `/` (index.html) | everyone | Professional home page (about, services, blood-group compatibility) |
| `/register.html` | User, Donor | Sign up – first choose the identity: **User** (needs blood) or **Donor** |
| `/login.html` | User, Donor | Sign in – choose the identity first; a donor cannot log in as a user and vice versa |
| `/admin-login.html` | Admin only | Admin portal login (no registration for admins; link is in the home page footer) |

## Dashboards

**User** (`/user.html`): Home · Request blood (send request) · Request history (cancel, see donor contact) · Profile

**Donor** (`/donor.html`): Home (availability, stats) · Blood requests (**Accept** / **Reject**) · History (mark donated / withdraw) · Profile

**Admin** (`/admin.html`): Home (live stats, latest requests, blood-bank stock) · User requests (reject, fulfil from stock, mark fulfilled) ·
Donor history · Manage users (activate/deactivate) · Manage donors (activate/deactivate) · Profile

## Real-time behaviour

| Action | Who gets a live update |
|--------|------------------------|
| User sends a request | Admin (notification + tables), every available donor whose blood group matches |
| Donor accepts | Admin, the requester (with donor's name), other donors (request disappears) |
| Donor withdraws | Admin, requester, matching donors (request is open again) |
| Donor marks donated / admin marks fulfilled | Admin, requester, the donor |
| User cancels | Admin, the accepted donor (if any), matching donors |
| Admin rejects / fulfils from stock | The requester, the donor (if any), matching donors |
| New user / donor registers | Admin |

A green **Live** dot in the top bar shows the connection is active (it reconnects automatically).

## Request life cycle

```
PENDING --(donor accepts)--> ACCEPTED --(donor or admin confirms)--> FULFILLED
   |                            |
   +-(admin: fulfil from stock)-+--> FULFILLED          PENDING/ACCEPTED --(admin rejects)--> REJECTED
                                                        PENDING/ACCEPTED --(user cancels)---> CANCELLED
```

Built-in rules: blood-group compatibility (O- gives to all), 90 days between donations, one active accepted
request per donor, donors cannot see contact details until they accept, two donors cannot accept the same
request at the same time (optimistic locking), a donor's *Reject* only hides the request from that donor,
a deactivated donor's accepted request goes back to the open list.

## Run it

You need **JDK 17+** and **Maven 3.8+**. MySQL 8 is needed for the default setup.

### Option A – MySQL
1. Start MySQL (the `bloodrescue` database is created automatically).
2. Put your MySQL password in `src/main/resources/application.properties`
   (`spring.datasource.password=...`) or set `DB_USERNAME` / `DB_PASSWORD`.
3. `mvn spring-boot:run` then open <http://localhost:8080>

### Option B – no MySQL (in-memory H2, data is lost on stop)
PowerShell: `mvn spring-boot:run "-Dspring-boot.run.profiles=h2"`
Linux/macOS: `mvn spring-boot:run -Dspring-boot.run.profiles=h2`

## Demo accounts (created on first start)

| Role | Login page | Email | Password |
|------|-----------|-------|----------|
| Admin | `/admin-login.html` | `admin@bloodrescue.com` | `Admin@123` |
| Donor (O+) | `/login.html` → Donor | `donor@bloodrescue.com` | `Donor@123` |
| Donor (A+) | `/login.html` → Donor | `donor2@bloodrescue.com` | `Donor@123` |
| User | `/login.html` → User | `user@bloodrescue.com` | `User@123` |

Set `bloodrescue.seed-demo-data=false` to create only the admin account. **Change the admin password** before real use.

### See the real-time flow (use 3 different browsers, or one normal window + two private/incognito windows)
> Tabs of the **same** browser share one login. Logging in as another role in a second tab switches the first tab
> to that account too, and its next action is refused with 403 (the app then asks you to log in again).
1. Window 1: log in as **Admin** (admin portal) and keep the dashboard open.
2. Window 2: log in as **Donor (A+)** (identity: Donor) and open *Blood requests*.
3. Window 3: log in as **User** → *Request blood* → send an A+ request.
4. Admin and the donor are notified instantly. Donor clicks **Accept** → the user and admin update live.
5. Donor → History → **Mark donated** → everyone sees *Fulfilled*; admin *Donor history* shows the donation.

## Project structure

```
src/main/java/com/bloodrescue/
  config/      SecurityConfig, DataSeeder
  controller/  Auth, User, Donor, Admin, Event (live stream), Public (home page numbers)
  service/     UserService, RequestService (rules + events), AdminService, LiveEventService
  model/       User, BloodRequest, BloodStock, RequestDecline, enums, BloodGroups
  repository/  Spring Data JPA repositories      dto/  Dtos, Mapper      exception/  ApiException, handler
src/main/resources/static/   index, login, register, admin-login, user, donor, admin (.html) + css/ + js/
database/schema.sql          reference schema (tables are auto-created anyway)
```

## REST API summary

| Area | Endpoints |
|------|-----------|
| Public | `GET /api/public/stats` |
| Auth | `POST /api/auth/register`, `POST /api/auth/login` (email, password, **role**), `POST /api/auth/logout`, `GET /api/auth/me`, `PUT /api/profile`, `POST /api/profile/password` |
| Live | `GET /api/events` (Server-Sent Events, any logged-in role) |
| User | `GET/POST /api/user/requests`, `POST /api/user/requests/{id}/cancel` |
| Donor | `GET /api/donor/stats`, `PUT /api/donor/availability`, `GET /api/donor/requests/open`, `GET /api/donor/requests/mine`, `POST /api/donor/requests/{id}/accept / reject / release / complete` |
| Admin | `GET /api/admin/stats`, `GET /api/admin/requests`, `POST /api/admin/requests/{id}/reject / fulfill-from-stock / fulfill`, `GET /api/admin/donations`, `GET /api/admin/users?role=USER or DONOR`, `PATCH /api/admin/users/{id}/status`, `GET /api/admin/stock`, `PUT /api/admin/stock/{group}` |

Security: session-cookie login, BCrypt hashing, role-based access per URL prefix, login checks the chosen identity,
server-side validation, HTML escaping in the frontend. (CSRF is disabled for simplicity – enable it for production.)




to run this project 

1.cd bloodrescue       
2.>> dir
3.mvn spring-boot:run "-Dspring-boot.run.profiles=h2"
