-- BloodRescue - MySQL reference schema
-- You do NOT have to run this: the application creates/updates these tables automatically
-- (spring.jpa.hibernate.ddl-auto=update). It is included so you can see/explain the database design.

CREATE DATABASE IF NOT EXISTS bloodrescue CHARACTER SET utf8mb4;
USE bloodrescue;

-- All people: requesters (USER), donors (DONOR) and the blood management team (ADMIN)
CREATE TABLE IF NOT EXISTS users (
    id                 BIGINT AUTO_INCREMENT PRIMARY KEY,
    name               VARCHAR(100) NOT NULL,
    email              VARCHAR(150) NOT NULL UNIQUE,
    password           VARCHAR(100) NOT NULL,          -- BCrypt hash, never plain text
    phone              VARCHAR(15),
    city               VARCHAR(80),
    blood_group        VARCHAR(4),                     -- A+, A-, B+, B-, AB+, AB-, O+, O-
    role               VARCHAR(10)  NOT NULL,          -- USER | DONOR | ADMIN
    active             BIT          NOT NULL DEFAULT 1,-- admin can deactivate an account
    available          BIT          NOT NULL DEFAULT 1,-- donor availability switch
    last_donation_date DATE,
    total_donations    INT          NOT NULL DEFAULT 0,
    created_at         DATETIME(6)  NOT NULL
);

-- A request for blood posted by a requester
CREATE TABLE IF NOT EXISTS blood_requests (
    id                    BIGINT AUTO_INCREMENT PRIMARY KEY,
    requester_id          BIGINT       NOT NULL,
    patient_name          VARCHAR(100) NOT NULL,
    blood_group           VARCHAR(4)   NOT NULL,
    units                 INT          NOT NULL,
    hospital              VARCHAR(150) NOT NULL,
    city                  VARCHAR(80)  NOT NULL,
    urgency               VARCHAR(10)  NOT NULL,       -- NORMAL | URGENT | CRITICAL
    required_date         DATE         NOT NULL,
    note                  VARCHAR(500),
    status                VARCHAR(10)  NOT NULL,       -- PENDING | ACCEPTED | FULFILLED | REJECTED | CANCELLED
    accepted_by_id        BIGINT,                      -- the donor who accepted
    admin_note            VARCHAR(500),
    fulfilled_from_stock  BIT          NOT NULL DEFAULT 0,
    created_at            DATETIME(6)  NOT NULL,
    updated_at            DATETIME(6)  NOT NULL,
    version               BIGINT       NOT NULL DEFAULT 0,   -- optimistic locking
    CONSTRAINT fk_req_requester FOREIGN KEY (requester_id)   REFERENCES users(id),
    CONSTRAINT fk_req_donor     FOREIGN KEY (accepted_by_id) REFERENCES users(id)
);

-- A donor pressed "Reject" on a request: it is hidden from that donor only
CREATE TABLE IF NOT EXISTS request_declines (
    id          BIGINT AUTO_INCREMENT PRIMARY KEY,
    request_id  BIGINT      NOT NULL,
    donor_id    BIGINT      NOT NULL,
    created_at  DATETIME(6) NOT NULL,
    CONSTRAINT uq_decline UNIQUE (request_id, donor_id),
    CONSTRAINT fk_decl_request FOREIGN KEY (request_id) REFERENCES blood_requests(id),
    CONSTRAINT fk_decl_donor   FOREIGN KEY (donor_id)   REFERENCES users(id)
);

-- Blood bank inventory (one row per blood group), managed by the admin team
CREATE TABLE IF NOT EXISTS blood_stock (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    blood_group  VARCHAR(4) NOT NULL UNIQUE,
    units        INT        NOT NULL,
    updated_at   DATETIME(6) NOT NULL
);

-- Useful queries for your viva / demo
-- Open requests waiting for donors:
--   SELECT id, patient_name, blood_group, urgency, hospital FROM blood_requests WHERE status = 'PENDING';
-- Top donors:
--   SELECT name, blood_group, total_donations FROM users WHERE role = 'DONOR' ORDER BY total_donations DESC;
-- Requests per status:
--   SELECT status, COUNT(*) FROM blood_requests GROUP BY status;
